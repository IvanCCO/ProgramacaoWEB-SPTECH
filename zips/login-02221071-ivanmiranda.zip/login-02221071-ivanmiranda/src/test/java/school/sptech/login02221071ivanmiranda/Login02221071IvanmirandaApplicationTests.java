package school.sptech.login02221071ivanmiranda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login02221071IvanmirandaApplicationTests {

	@Test
	void contextLoads() {
	}

}
