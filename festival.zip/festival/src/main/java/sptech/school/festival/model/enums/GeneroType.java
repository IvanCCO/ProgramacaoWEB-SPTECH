package sptech.school.festival.model.enums;

public enum GeneroType {
    ROCK, FUNK, RAP, POP_NACIONAL, POP_INTERNACIONAL
}
