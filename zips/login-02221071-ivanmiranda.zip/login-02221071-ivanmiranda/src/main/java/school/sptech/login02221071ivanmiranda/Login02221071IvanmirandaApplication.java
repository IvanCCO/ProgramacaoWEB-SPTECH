package school.sptech.login02221071ivanmiranda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login02221071IvanmirandaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login02221071IvanmirandaApplication.class, args);
	}

}
